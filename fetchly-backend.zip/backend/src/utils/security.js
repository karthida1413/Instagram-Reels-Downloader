// Security helpers shared across routes.
//
// The most important one is `assertSafeUrl`: because this server fetches
// URLs supplied by end users (to read metadata / proxy a direct media
// download), it is a textbook SSRF target if left unchecked — a malicious
// user could ask it to fetch http://169.254.169.254/ (cloud metadata),
// http://localhost:6379 (an internal Redis instance), etc. We block that.

const dns = require('node:dns').promises;
const ipaddr = require('ipaddr.js');

const ALLOWED_PROTOCOLS = new Set(['http:', 'https:']);

// Private / loopback / link-local / cloud-metadata ranges to block.
const BLOCKED_RANGES = [
  '127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16',
  '169.254.0.0/16', // includes 169.254.169.254 cloud metadata endpoint
  '::1/128', 'fc00::/7', 'fe80::/10',
  '0.0.0.0/8',
];

function isBlockedIp(ip) {
  try {
    const addr = ipaddr.process(ip);
    return BLOCKED_RANGES.some(range => {
      const [rangeAddr, bits] = range.split('/');
      const parsed = ipaddr.process(rangeAddr);
      if (parsed.kind() !== addr.kind()) return false;
      return addr.match(parsed, Number(bits));
    });
  } catch {
    return true; // fail closed on anything unparsable
  }
}

/**
 * Validates a user-supplied URL is syntactically sound, uses http(s),
 * and does not resolve to a private/internal address. Throws on failure.
 */
async function assertSafeUrl(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw httpError(400, 'Invalid URL');
  }
  if (!ALLOWED_PROTOCOLS.has(url.protocol)) {
    throw httpError(400, 'Only http/https URLs are allowed');
  }
  if (!url.hostname || url.hostname === 'localhost') {
    throw httpError(400, 'URL host not allowed');
  }

  let addresses;
  try {
    addresses = await dns.lookup(url.hostname, { all: true });
  } catch {
    throw httpError(400, 'Could not resolve host');
  }
  if (addresses.some(a => isBlockedIp(a.address))) {
    throw httpError(400, 'URL resolves to a blocked/internal address');
  }
  return url;
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  err.expose = true;
  return err;
}

/** Basic sanitizer for filenames derived from user/remote data. */
function sanitizeFilename(name, fallback = 'download') {
  const cleaned = (name || fallback)
    .normalize('NFKD')
    .replace(/[^\w.\- ]/g, '')
    .trim()
    .slice(0, 80);
  return cleaned || fallback;
}

module.exports = { assertSafeUrl, sanitizeFilename, httpError };
