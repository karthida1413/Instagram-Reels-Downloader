// Maps a URL to a platform id + which adapter (if any) can legitimately
// fetch metadata for it. This mirrors the frontend's detector so both
// sides agree on platform naming.

const PLATFORMS = [
  { id: 'youtube', test: /youtube\.com|youtu\.be/i },
  { id: 'vimeo', test: /vimeo\.com/i },
  { id: 'tiktok', test: /tiktok\.com/i },
  { id: 'twitter', test: /twitter\.com|x\.com/i },
  { id: 'dailymotion', test: /dailymotion\.com|dai\.ly/i },
  { id: 'instagram', test: /instagram\.com/i },
  { id: 'facebook', test: /facebook\.com|fb\.watch/i },
  { id: 'pinterest', test: /pinterest\.[a-z.]+|pin\.it/i },
  { id: 'threads', test: /threads\.net/i },
];

const DIRECT_MEDIA_RE = /\.(jpe?g|png|gif|webp|heic|mp4|mov|m4v|webm|mp3|m4a)(\?.*)?$/i;

function detectPlatform(url) {
  const match = PLATFORMS.find(p => p.test.test(url));
  return match ? match.id : null;
}

function isDirectMedia(url) {
  return DIRECT_MEDIA_RE.test(url);
}

module.exports = { detectPlatform, isDirectMedia };
