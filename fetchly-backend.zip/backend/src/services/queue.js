// A small in-process queue that caps how many downloads run at once,
// so a burst of requests can't exhaust memory/bandwidth. For a
// multi-instance deployment, swap this for a Redis-backed queue
// (e.g. BullMQ) using the same `enqueue` interface.
const PQueueModule = require('p-queue');
const PQueue = PQueueModule.default || PQueueModule;
const config = require('../config');
const logger = require('../logger');

const queue = new PQueue({ concurrency: config.queueConcurrency });

queue.on('active', () => {
  logger.debug({ size: queue.size, pending: queue.pending }, 'Queue active');
});

function enqueue(task) {
  return queue.add(task);
}

function stats() {
  return { size: queue.size, pending: queue.pending, concurrency: config.queueConcurrency };
}

module.exports = { enqueue, stats };
