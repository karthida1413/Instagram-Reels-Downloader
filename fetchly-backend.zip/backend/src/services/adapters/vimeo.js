// Vimeo's official oEmbed endpoint. Public videos only — private/
// password-protected videos will simply fail, which is correct.
const { fetchOembed } = require('./oembedClient');

async function analyze(url) {
  const data = await fetchOembed('https://vimeo.com/api/oembed.json', url);
  return {
    title: data.title,
    uploader: data.author_name,
    thumb: data.thumbnail_url,
    kind: 'video',
    duration: data.duration ? formatDuration(data.duration) : null,
    resolution: data.width && data.height ? `${data.width}×${data.height}` : null,
    size: null,
    qualities: [{ label: 'Video (preview only)', size: null, res: null, url: null }],
    notes: 'Metadata via Vimeo\u2019s official oEmbed endpoint. Downloadable files are only available for videos whose owner has enabled Vimeo\u2019s own download feature.',
  };
}

function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

module.exports = { analyze };
