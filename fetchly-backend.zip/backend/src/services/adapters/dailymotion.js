const { fetchOembed } = require('./oembedClient');

async function analyze(url) {
  const data = await fetchOembed('https://www.dailymotion.com/services/oembed', url);
  return {
    title: data.title,
    uploader: data.author_name,
    thumb: data.thumbnail_url,
    kind: 'video',
    duration: data.duration ? formatDuration(data.duration) : null,
    resolution: data.width && data.height ? `${data.width}×${data.height}` : null,
    size: null,
    qualities: [{ label: 'Video (preview only)', size: null, res: null, url: null }],
    notes: 'Metadata via Dailymotion\u2019s official oEmbed endpoint.',
  };
}

function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

module.exports = { analyze };
