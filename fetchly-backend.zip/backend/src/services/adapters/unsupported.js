// Pinterest and Threads don't currently publish a public, no-auth
// oEmbed/metadata endpoint. Rather than scrape their pages (which would
// violate their Terms of Service), this adapter returns a clear,
// honest error so the frontend can fall back to its own demo/sample
// preview state.
const { httpError } = require('../../utils/security');

async function analyze(url, platform) {
  throw httpError(
    501,
    `${platform} does not offer a public metadata API, so Fetchly can't fetch a real preview for it without scraping — which we won't do. Consider linking your own licensed data source for this platform.`
  );
}

module.exports = { analyze };
