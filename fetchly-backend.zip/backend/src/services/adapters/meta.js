// Instagram and Facebook do NOT offer a public, no-auth oEmbed endpoint
// anymore — Meta's oEmbed Read feature requires a Meta Developer app
// that has gone through App Review and holds a valid access token, and
// its use is governed by Meta's Platform Terms (e.g. you generally need
// the content owner's permission or an approved use case).
//
// This adapter intentionally does NOT ship a working implementation.
// If you have your own approved Meta app, set META_GRAPH_APP_TOKEN in
// .env and fill in the fetch call below per Meta's current oEmbed Read
// documentation. Without that, we return a clear 501 rather than
// silently failing or, worse, scraping the page.

const config = require('../../config');
const { httpError } = require('../../utils/security');

async function analyze(url, platform) {
  if (!config.metaGraphAppToken) {
    throw httpError(
      501,
      `${platform === 'instagram' ? 'Instagram' : 'Facebook'} metadata requires your own approved Meta Graph API app token. See README for setup — Fetchly does not include one.`
    );
  }

  // Example shape once you have a token (uncomment and adapt):
  //
  // const { request } = require('undici');
  // const qs = new URLSearchParams({ url, access_token: config.metaGraphAppToken });
  // const res = await request(`https://graph.facebook.com/v19.0/oembed_${platform}?${qs}`);
  // const data = await res.body.json();
  // return { title: data.title, uploader: data.author_name, thumb: data.thumbnail_url, ... };

  throw httpError(501, 'Meta oEmbed integration not configured.');
}

module.exports = { analyze };
