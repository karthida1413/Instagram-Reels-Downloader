// YouTube's official oEmbed endpoint (no API key required) returns
// title, author_name and thumbnail_url for any public video/short URL.
// It does NOT return a video stream — downloading YouTube video/audio
// requires their Data API + licensing terms most consumer apps don't
// have, so we deliberately stop at metadata here.
const { fetchOembed } = require('./oembedClient');

async function analyze(url) {
  const data = await fetchOembed('https://www.youtube.com/oembed', url);
  const isShort = /\/shorts\//.test(url);
  return {
    title: data.title,
    uploader: data.author_name,
    thumb: data.thumbnail_url,
    kind: 'video',
    duration: null,
    resolution: data.width && data.height ? `${data.width}×${data.height}` : null,
    size: null,
    qualities: [
      { label: isShort ? 'Short (preview only)' : 'Video (preview only)', size: null, res: null, url: null },
    ],
    notes: 'Metadata via YouTube\u2019s official oEmbed endpoint. Actual video download requires your own licensed integration with the YouTube Data API and is out of scope here.',
  };
}

module.exports = { analyze };
