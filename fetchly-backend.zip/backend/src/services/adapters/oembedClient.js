// Thin wrapper around each platform's OFFICIAL oEmbed endpoint.
//
// oEmbed is a public protocol platforms publish specifically so third
// parties can show a title/author/thumbnail preview for a URL — it's the
// same mechanism Slack/Discord/WordPress use for link previews. It never
// returns a downloadable video file, only preview metadata, which is why
// this is safe to call directly with no scraping involved.

const { request } = require('undici');
const config = require('../../config');

async function fetchOembed(endpoint, targetUrl, extraParams = {}) {
  const qs = new URLSearchParams({ url: targetUrl, format: 'json', ...extraParams });
  const res = await request(`${endpoint}?${qs.toString()}`, {
    method: 'GET',
    headersTimeout: config.downloadTimeoutMs,
    bodyTimeout: config.downloadTimeoutMs,
  });
  if (res.statusCode >= 400) {
    const err = new Error(`Provider oEmbed request failed (${res.statusCode})`);
    err.status = 502;
    err.expose = true;
    throw err;
  }
  return res.body.json();
}

module.exports = { fetchOembed };
