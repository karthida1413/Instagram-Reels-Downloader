// TikTok publishes an official oEmbed endpoint at tiktok.com/oembed for
// public videos. As with the others, this is preview metadata only.
const { fetchOembed } = require('./oembedClient');

async function analyze(url) {
  const data = await fetchOembed('https://www.tiktok.com/oembed', url);
  return {
    title: data.title,
    uploader: data.author_name,
    thumb: data.thumbnail_url,
    kind: 'video',
    duration: null,
    resolution: data.thumbnail_width && data.thumbnail_height
      ? `${data.thumbnail_width}×${data.thumbnail_height}` : null,
    size: null,
    qualities: [{ label: 'Video (preview only)', size: null, res: null, url: null }],
    notes: 'Metadata via TikTok\u2019s official oEmbed endpoint. TikTok does not offer a public download API.',
  };
}

module.exports = { analyze };
