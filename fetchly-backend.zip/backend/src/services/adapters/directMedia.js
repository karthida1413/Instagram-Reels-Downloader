// For a URL that already points straight at an image/video/audio file,
// there's nothing to "extract" — we just look at it. This is the same
// as a browser's normal fetch/HEAD behavior, not a bypass of anything.
const { request } = require('undici');
const config = require('../../config');
const { assertSafeUrl, sanitizeFilename } = require('../../utils/security');

async function analyze(rawUrl) {
  const url = await assertSafeUrl(rawUrl);

  let contentLength = null;
  let contentType = null;
  try {
    const res = await request(url, {
      method: 'HEAD',
      headersTimeout: config.downloadTimeoutMs,
      bodyTimeout: config.downloadTimeoutMs,
    });
    contentLength = res.headers['content-length'] ? Number(res.headers['content-length']) : null;
    contentType = res.headers['content-type'] || null;
  } catch {
    // Some hosts reject HEAD; we degrade gracefully rather than fail outright.
  }

  const isVideo = /\.(mp4|mov|m4v|webm)(\?.*)?$/i.test(url.pathname) || (contentType || '').startsWith('video');
  const isAudio = /\.(mp3|m4a)(\?.*)?$/i.test(url.pathname) || (contentType || '').startsWith('audio');
  const kind = isAudio ? 'audio' : isVideo ? 'video' : 'image';
  const filename = sanitizeFilename(decodeURIComponent(url.pathname.split('/').pop() || 'file'));

  return {
    title: filename,
    uploader: url.hostname,
    thumb: kind === 'image' ? url.href : null,
    kind,
    duration: null,
    resolution: null,
    size: contentLength ? formatBytes(contentLength) : null,
    qualities: [{ label: 'Original file', size: contentLength ? formatBytes(contentLength) : null, res: 'Source', url: url.href }],
  };
}

function formatBytes(n) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
}

module.exports = { analyze };
