// X/Twitter's official oEmbed endpoint (publish.twitter.com) returns
// embed HTML and author info for a public post. It does not expose a
// direct media file URL, so downloads are out of scope here.
const { fetchOembed } = require('./oembedClient');

async function analyze(url) {
  const data = await fetchOembed('https://publish.twitter.com/oembed', url);
  return {
    title: stripHtml(data.html).slice(0, 140) || 'Post on X',
    uploader: data.author_name,
    thumb: null,
    kind: 'video',
    duration: null,
    resolution: null,
    size: null,
    qualities: [{ label: 'Media (preview only)', size: null, res: null, url: null }],
    notes: 'Metadata via X\u2019s official oEmbed endpoint. Media file download is not exposed by this endpoint.',
  };
}

function stripHtml(html) {
  return (html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

module.exports = { analyze };
