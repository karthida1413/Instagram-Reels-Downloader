// Loads and validates environment variables in one place so the rest
// of the app never touches process.env directly.
require('dotenv').config();

function num(name, fallback) {
  const v = process.env[name];
  return v ? Number(v) : fallback;
}
function list(name, fallback) {
  const v = process.env[name];
  return v ? v.split(',').map(s => s.trim()).filter(Boolean) : fallback;
}

module.exports = {
  port: num('PORT', 8080),
  env: process.env.NODE_ENV || 'development',
  logLevel: process.env.LOG_LEVEL || 'info',

  corsOrigins: list('CORS_ORIGINS', ['http://localhost:3000']),

  rateLimit: {
    windowMs: num('RATE_LIMIT_WINDOW_MS', 60_000),
    max: num('RATE_LIMIT_MAX', 30),
  },
  downloadRateLimit: {
    windowMs: num('RATE_LIMIT_WINDOW_MS', 60_000),
    max: num('DOWNLOAD_RATE_LIMIT_MAX', 10),
  },

  maxDownloadBytes: num('MAX_DOWNLOAD_BYTES', 500 * 1024 * 1024), // 500MB
  downloadTimeoutMs: num('DOWNLOAD_TIMEOUT_MS', 30_000),
  queueConcurrency: num('QUEUE_CONCURRENCY', 4),

  metaGraphAppToken: process.env.META_GRAPH_APP_TOKEN || null,
};
