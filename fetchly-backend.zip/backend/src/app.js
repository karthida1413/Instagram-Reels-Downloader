const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const pinoHttp = require('pino-http');

const config = require('./config');
const logger = require('./logger');
const { apiLimiter } = require('./middleware/rateLimiter');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const healthRoute = require('./routes/health');
const analyzeRoute = require('./routes/analyze');
const downloadRoute = require('./routes/download');

const app = express();

// Trust the first proxy hop (needed on Render/Railway/behind Nginx so
// req.ip / rate limiting see the real client IP, not the proxy's).
app.set('trust proxy', 1);

// ---- Security headers ----
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
    },
  },
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// ---- CORS ----
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || config.corsOrigins.includes('*') || config.corsOrigins.includes(origin)) {
      return callback(null, true);
    }
    callback(new Error('Not allowed by CORS'));
  },
  methods: ['GET', 'POST'],
}));

app.use(compression());
app.use(express.json({ limit: '32kb' })); // small limit: bodies are just { url }
app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/api/health' } }));

// ---- Rate limiting (applies to all /api routes) ----
app.use('/api', apiLimiter);

// ---- Routes ----
app.use('/api', healthRoute);
app.use('/api', analyzeRoute);
app.use('/api', downloadRoute);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
