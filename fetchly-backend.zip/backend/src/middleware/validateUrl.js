const { httpError } = require('../utils/security');

// Validates that req.body.url is present and a plausible URL before it
// reaches any route handler or adapter. Deep SSRF-safety checks happen
// later via assertSafeUrl once we're about to actually fetch it.
function requireUrlInBody(req, res, next) {
  const { url } = req.body || {};
  if (!url || typeof url !== 'string') {
    return next(httpError(400, 'Request body must include a "url" string'));
  }
  if (url.length > 2048) {
    return next(httpError(400, 'URL is too long'));
  }
  try {
    new URL(url);
  } catch {
    return next(httpError(400, 'URL is not valid'));
  }
  next();
}

module.exports = { requireUrlInBody };
