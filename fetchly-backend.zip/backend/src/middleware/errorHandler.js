const logger = require('../logger');

// 404 handler — mounted after all routes.
function notFound(req, res) {
  res.status(404).json({ error: 'Not found' });
}

// Final error handler — mounted last. Never leaks stack traces to clients.
function errorHandler(err, req, res, _next) { // eslint-disable-line no-unused-vars
  const status = err.status || 500;
  const message = err.expose ? err.message : 'Something went wrong on our end';

  if (status >= 500) {
    logger.error({ err, path: req.path }, 'Unhandled error');
  } else {
    logger.warn({ msg: err.message, path: req.path }, 'Request error');
  }

  res.status(status).json({ error: message });
}

module.exports = { notFound, errorHandler };
