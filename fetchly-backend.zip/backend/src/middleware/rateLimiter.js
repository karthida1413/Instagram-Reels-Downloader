const rateLimit = require('express-rate-limit');
const config = require('../config');

// General API rate limit — applied to all /api routes.
const apiLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down and try again shortly.' },
});

// Stricter limit specifically for downloads, since they're heavier.
const downloadLimiter = rateLimit({
  windowMs: config.downloadRateLimit.windowMs,
  max: config.downloadRateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Download limit reached. Please wait a minute before trying again.' },
});

module.exports = { apiLimiter, downloadLimiter };
