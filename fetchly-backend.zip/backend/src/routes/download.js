const express = require('express');
const { request } = require('undici');
const { requireUrlInBody } = require('../middleware/validateUrl');
const { assertSafeUrl, sanitizeFilename, httpError } = require('../utils/security');
const { downloadLimiter } = require('../middleware/rateLimiter');
const queue = require('../services/queue');
const config = require('../config');
const logger = require('../logger');

const router = express.Router();

// POST /api/download  { url, filename? }
// Streams a direct media file back to the client through this server
// (useful when the source blocks cross-origin fetches from the browser),
// enforcing a size cap, timeout, and content-type allowlist.
router.post('/download', downloadLimiter, requireUrlInBody, async (req, res, next) => {
  try {
    const safeUrl = await assertSafeUrl(req.body.url);
    const filename = sanitizeFilename(req.body.filename, safeUrl.pathname.split('/').pop());

    await queue.enqueue(() => streamDownload(safeUrl, filename, req, res));
  } catch (err) {
    next(err);
  }
});

async function streamDownload(url, filename, req, res) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.downloadTimeoutMs);
  req.on('close', () => controller.abort());

  let upstream;
  try {
    upstream = await request(url, { method: 'GET', signal: controller.signal });
  } catch (err) {
    clearTimeout(timeout);
    throw httpError(502, 'Could not reach the source file');
  }

  if (upstream.statusCode >= 400) {
    clearTimeout(timeout);
    throw httpError(502, `Source returned ${upstream.statusCode}`);
  }

  const contentType = upstream.headers['content-type'] || 'application/octet-stream';
  const declaredLength = Number(upstream.headers['content-length'] || 0);
  if (declaredLength && declaredLength > config.maxDownloadBytes) {
    clearTimeout(timeout);
    throw httpError(413, 'File exceeds the maximum allowed download size');
  }

  res.setHeader('Content-Type', contentType);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  if (declaredLength) res.setHeader('Content-Length', String(declaredLength));

  let received = 0;
  upstream.body.on('data', (chunk) => {
    received += chunk.length;
    if (received > config.maxDownloadBytes) {
      logger.warn({ url: url.href }, 'Download exceeded max size mid-stream, aborting');
      controller.abort();
      res.destroy();
    }
  });

  upstream.body.on('error', () => { clearTimeout(timeout); if (!res.headersSent) res.status(502); res.end(); });
  res.on('close', () => clearTimeout(timeout));

  upstream.body.pipe(res);
}

module.exports = router;
