const express = require('express');
const { requireUrlInBody } = require('../middleware/validateUrl');
const { detectPlatform, isDirectMedia } = require('../services/platformDetector');
const { httpError } = require('../utils/security');

const directMedia = require('../services/adapters/directMedia');
const youtube = require('../services/adapters/youtube');
const vimeo = require('../services/adapters/vimeo');
const tiktok = require('../services/adapters/tiktok');
const twitter = require('../services/adapters/twitter');
const dailymotion = require('../services/adapters/dailymotion');
const meta = require('../services/adapters/meta');
const unsupported = require('../services/adapters/unsupported');

const router = express.Router();

// POST /api/analyze  { url }
// Returns the same shape the Fetchly frontend already expects:
// { title, uploader, thumb, kind, duration, resolution, size, qualities[] }
router.post('/analyze', requireUrlInBody, async (req, res, next) => {
  const { url } = req.body;

  try {
    if (isDirectMedia(url)) {
      const result = await directMedia.analyze(url);
      return res.json({ ...result, isDemo: false, sourceUrl: url });
    }

    const platform = detectPlatform(url);
    if (!platform) {
      throw httpError(422, 'Could not recognize this link as a supported platform or direct media file.');
    }

    let result;
    switch (platform) {
      case 'youtube':      result = await youtube.analyze(url); break;
      case 'vimeo':        result = await vimeo.analyze(url); break;
      case 'tiktok':       result = await tiktok.analyze(url); break;
      case 'twitter':      result = await twitter.analyze(url); break;
      case 'dailymotion':  result = await dailymotion.analyze(url); break;
      case 'instagram':    result = await meta.analyze(url, 'instagram'); break;
      case 'facebook':     result = await meta.analyze(url, 'facebook'); break;
      default:              result = await unsupported.analyze(url, platform); break;
    }

    res.json({ ...result, isDemo: false, sourceUrl: url, platform });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
