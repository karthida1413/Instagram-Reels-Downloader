const express = require('express');
const queue = require('../services/queue');

const router = express.Router();

router.get('/health', (req, res) => {
  res.json({ status: 'ok', uptimeSeconds: Math.round(process.uptime()), queue: queue.stats() });
});

module.exports = router;
