# Deployment Guide

This backend does long-lived streaming responses (`/api/download`) and
benefits from a persistent process, so a traditional Node server (Render,
Railway, VPS) is a better fit than a serverless platform. Vercel notes are
included for the parts that do work there (health/analyze), with caveats.

---

## Render

1. Push this `backend/` folder to a Git repo.
2. In Render: **New → Web Service**, connect the repo, root directory `backend/`.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env.example` under **Environment**.
6. Render provides HTTPS automatically. Set `CORS_ORIGINS` to your frontend's
   deployed URL.

---

## Railway

1. `railway init` inside `backend/`, or connect the repo via the Railway
   dashboard.
2. Railway auto-detects Node from `package.json`; confirm start command is
   `npm start`.
3. Add the variables from `.env.example` in **Variables**.
4. Railway assigns a public HTTPS domain automatically (or attach a custom
   domain under **Settings → Domains**).

---

## Vercel (serverless — partial fit)

Vercel's functions are short-lived and don't support long streaming
downloads well. If you still want to host the JSON endpoints there:

1. Add a `vercel.json` that routes `/api/*` to `src/app.js` wrapped as a
   serverless function (Vercel's Node runtime supports Express apps via
   `module.exports = app` with no `app.listen()` — use a separate
   `api/index.js` that does `module.exports = require('../src/app')`).
2. Set the same environment variables in **Project Settings → Environment
   Variables**.
3. Expect `/api/download` to fail or time out for large files — better to
   deploy just `/api/analyze` + `/api/health` here and run `/api/download`
   on Render/Railway/VPS instead, pointing the frontend's download calls at
   that second URL.

---

## VPS (Ubuntu + Nginx + PM2 + Let's Encrypt)

```bash
# 1. Install Node
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 2. Get the code and install deps
git clone <your-repo> fetchly-backend && cd fetchly-backend/backend
cp .env.example .env   # edit values
npm install --omit=dev

# 3. Run under PM2 for auto-restart
sudo npm install -g pm2
pm2 start src/index.js --name fetchly-backend
pm2 save
pm2 startup   # follow the printed instructions to enable on boot
```

**Nginx reverse proxy** (`/etc/nginx/sites-available/fetchly-backend`):

```nginx
server {
    listen 80;
    server_name your-api.example.com;

    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_buffering off; # important for streaming downloads
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/fetchly-backend /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# HTTPS
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-api.example.com
```

## Docker (any host)

```bash
cd backend
cp .env.example .env   # edit values
docker compose up -d --build
```

## After deploying anywhere

1. Confirm `GET https://your-api.example.com/api/health` returns `200`.
2. Set `CORS_ORIGINS` in `.env` to the exact origin your frontend is served
   from (e.g. `https://fetchly.example.com`), not `*`, before going live.
3. In the Fetchly frontend, open **Settings → Backend API URL** and paste
   your deployed base URL.
