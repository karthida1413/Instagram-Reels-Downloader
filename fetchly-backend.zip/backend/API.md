# Fetchly API Reference

Base URL: `https://your-api.example.com` (or `http://localhost:8080` locally)

All responses are JSON. All errors follow `{ "error": "message" }`.

---

## `GET /api/health`

Health check.

**Response `200`**
```json
{ "status": "ok", "uptimeSeconds": 1234, "queue": { "size": 0, "pending": 0, "concurrency": 4 } }
```

---

## `POST /api/analyze`

Fetch a preview for a link.

**Request body**
```json
{ "url": "https://youtube.com/watch?v=..." }
```

**Response `200`** (shape matches what the frontend expects)
```json
{
  "title": "string",
  "uploader": "string | null",
  "thumb": "string (URL) | null",
  "kind": "video | image | audio",
  "duration": "string | null",
  "resolution": "string | null",
  "size": "string | null",
  "qualities": [
    { "label": "string", "size": "string | null", "res": "string | null", "url": "string | null" }
  ],
  "isDemo": false,
  "sourceUrl": "https://...",
  "platform": "youtube | vimeo | tiktok | twitter | dailymotion | instagram | facebook | null"
}
```

Note: for platform links (as opposed to direct media files), `qualities[].url`
is `null` — this backend only returns official preview metadata for those
platforms, not a downloadable file, per the ToS/legal notes in `README.md`.

**Errors**
- `400` — malformed request or URL
- `422` — URL doesn't match a supported platform or direct media file
- `501` — platform recognized but no legitimate metadata source is configured
  (Instagram/Facebook without a Meta app token, or Pinterest/Threads)
- `502` — upstream provider request failed

---

## `POST /api/download`

Streams a direct media file back through the server.

**Request body**
```json
{ "url": "https://example.com/photo.jpg", "filename": "optional-name.jpg" }
```

**Response `200`** — binary stream with `Content-Type` and
`Content-Disposition: attachment` headers set from the source.

**Errors**
- `400` — invalid URL, or URL resolves to a blocked/internal address
- `413` — file exceeds `MAX_DOWNLOAD_BYTES`
- `429` — rate limit exceeded (`DOWNLOAD_RATE_LIMIT_MAX` per `RATE_LIMIT_WINDOW_MS`)
- `502` — could not reach or read from the source

---

## Rate limits

| Route             | Default limit                  |
|--------------------|--------------------------------|
| all `/api/*`        | 30 requests / 60s per IP       |
| `/api/download`    | 10 requests / 60s per IP       |

Configurable via `.env` (`RATE_LIMIT_MAX`, `DOWNLOAD_RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_MS`).
