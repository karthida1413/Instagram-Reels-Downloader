# Fetchly Backend

A Node.js + Express API that pairs with the Fetchly frontend. It provides:

- `POST /api/analyze` — metadata preview for a link
- `POST /api/download` — proxied streaming download for a direct media file
- `GET /api/health` — health check

## What this backend does and does not do

**Does:** real metadata lookups via each platform's **official, public oEmbed
endpoint** (YouTube, Vimeo, TikTok, X/Twitter, Dailymotion) — the same
mechanism those platforms use for link-preview embeds. Also does real,
size-capped, SSRF-protected streaming of any direct media URL you already
have (e.g. a `.mp4` you host, or a public image URL).

**Does not:** scrape or reverse-engineer Instagram, Facebook, Pinterest,
TikTok's, YouTube's, etc. private video-delivery mechanisms to extract
downloadable video files. Doing so would violate those platforms' Terms of
Service. The `meta.js` and `unsupported.js` adapters are stubs that explain
this and return a clear `501` instead of pretending to work. If you have a
legitimate licensing/API relationship with a platform, wire it in at those
files.

## Requirements

- Node.js 18+
- npm

## Setup

```bash
cp .env.example .env
npm install
npm run dev      # local dev, auto-reload
npm start        # production
```

Server starts on `http://localhost:8080` by default.

## Folder structure

```
backend/
├── src/
│   ├── index.js              # entrypoint, graceful shutdown
│   ├── app.js                # Express app: helmet, cors, routes
│   ├── config.js             # env var loader
│   ├── logger.js             # pino logger
│   ├── routes/
│   │   ├── analyze.js
│   │   ├── download.js
│   │   └── health.js
│   ├── middleware/
│   │   ├── rateLimiter.js
│   │   ├── validateUrl.js
│   │   └── errorHandler.js
│   ├── services/
│   │   ├── platformDetector.js
│   │   ├── queue.js
│   │   └── adapters/
│   │       ├── oembedClient.js
│   │       ├── youtube.js / vimeo.js / tiktok.js / twitter.js / dailymotion.js
│   │       ├── directMedia.js
│   │       ├── meta.js         (stub — needs your own Meta app token)
│   │       └── unsupported.js  (stub — Pinterest/Threads etc.)
│   └── utils/
│       └── security.js       # SSRF protection, filename sanitizing
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── package.json
```

## Connecting to the frontend

In the Fetchly single-page app, open **Settings → Backend API URL** and enter
this server's base URL (e.g. `https://your-api.example.com`). The frontend
will POST to `<that URL>/api/analyze` automatically.

## Security features included

- Helmet security headers + CSP
- CORS allow-list via `CORS_ORIGINS`
- Rate limiting (general + stricter on `/api/download`)
- SSRF protection: blocks requests to private/loopback/link-local IPs
  and cloud metadata endpoints before any outbound fetch
- Request body size limit
- Download size cap + timeout, streamed (not buffered) to keep memory flat
- Filename sanitization
- Centralized error handler that never leaks stack traces

## See also

- `API.md` — endpoint reference
- `DEPLOY.md` — Vercel, Render, Railway, and VPS deployment steps
